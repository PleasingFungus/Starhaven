This disclaimer and license agreement is a legal agreement between you and Fonts For Flash. By purchasing these fonts, you agree that you have read and understood this disclaimer in its entirety and accept its contents.

Fonts may be used for personal and/or commercial projects such as websites, offline presentations and other multimedia ventures. These fonts may be used for single or multiple users depending on the type of license purchased. 

A font for which an unlimited user license is purchased, may be used on an unlimited amount of computers within the same organization only, and cannot be distributed to other companies or third parties under this agreement.FFF fonts may not be redistributed, modified or resold in any way without the written permission of Fonts For Flash.Fonts For Flash does not take any responsibility for any damage caused through use of these fonts, be it indirect, special, incidental or consequential damages (including damages for loss of business, loss of profits, interruption or the like).

These fonts are designed to work on the specific operating system for which they were purchased only. Fonts For Flash does not take responsibility for the correct workings of a font that has been converted from PC to Macintosh or vice versa, or by use in programs other than Macromedia Flash 5 or Flash MX and/or ways not specifically designed for. 

Ensure that you have read the Frequently Asked Questions and the user guide (provided with your download) in the FFF website for all the technical details.All fonts are sold on an AS IS basis. 

All available characters can be seen on the font preview screen and all additional characters could be supplied by special order only.You agree that you have viewed and tested the fonts that you wish to purchase and are satisfied with the quality and that you will not hold Fonts For Flash responsible in any way.
Fonts are guaranteed to work provided that you follow the guidelines for its usage. Any problems will be addressed and corrected.

If there are any upgrades to the fonts you have purchased, these will be provided to you free of charge. It is understood that all fonts received by way of a free upgrade, are accepted under the same terms and conditions as stated here.

Purchasing any fonts means that you have understood and agreed to all the terms and conditions on this disclaimer.

Thank you.
The FFF Team
www.fontsforflash.com